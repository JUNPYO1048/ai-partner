import streamlit as st
import requests
import os

st.set_page_config(page_title="AI Partner Beta", layout="centered")
st.title("🔐 AI Partner Beta 테스트")

st.markdown("### 로그인 (이메일/비밀번호)")
email = st.text_input("이메일")
password = st.text_input("비밀번호", type="password")

if st.button("로그인"):
    st.warning("Firebase 인증은 배포 환경에서만 작동합니다.")
    st.info(f"입력된 이메일: {email}")
    st.success("(베타용 로그인 테스트 UI입니다)")

st.markdown("---")

option = st.selectbox("기능 선택", ["블로그 생성", "유튜브 스크립트 생성", "고객응대 응답"])
input_text = st.text_input("주제 또는 질문 입력")

if st.button("생성하기"):
    st.write("🔧 생성 결과 (예시 출력)")
    st.markdown(f"**입력 내용:** {input_text}")
    st.success("여기에 생성된 결과가 표시될 예정입니다.")
